"use client";

async function fetchRandomDog() {
  const response = await fetch("https://dog.ceo/api/breeds/image/random");
  const data = await response.json(); //filters response to js object, removes headers
  return data.message; //from json response
}

// Promises can have three different states:
// 1.

export default function Page() {
  async function loadRandomDog() {
    const randomDog = await fetchRandomDog();
    console.log(randomDog);
  }
  const randomDog = fetchRandomDog();
  console.log(randomDog);

  return (
    <main>
      <h1>Dogs!</h1>
      <div>image</div>
    </main>
  );
}
